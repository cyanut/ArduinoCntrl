============================
BundlePmw.py
============================

A fork of bundlepmw.py from Pmw (Python Mega Widget)
and http://stackoverflow.com/questions/6772916/python-pmw-and-cx-freeze
